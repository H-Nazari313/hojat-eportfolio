const container = document.querySelector('.project-container');
const cards = document.querySelectorAll('.project-card');
let index = 0;

document.getElementById('next').addEventListener('click', () => {
  if (index < cards.length - 1) index++;
  container.style.transform = `translateX(-${index * (cards[0].offsetWidth + 20)}px)`;
});

document.getElementById('prev').addEventListener('click', () => {
  if (index > 0) index--;
  container.style.transform = `translateX(-${index * (cards[0].offsetWidth + 20)}px)`;
});

document.getElementById('toggle-mode').addEventListener('click', () => {
  document.body.classList.toggle('light-mode');
});
